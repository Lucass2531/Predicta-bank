import { useState, useEffect } from 'react'
import { Zap, TrendingDown, TrendingUp } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

interface Scenario {
  name: string
  reduction: number
  projectedBalance: number
  savings: number
  impact: string
}

export default function FinancialSimulator({ transactions, balance, onSimulate }) {
  const [scenarios, setScenarios] = useState<Scenario[]>([])

  useEffect(() => {
    // Calcular automaticamente os cenários de simulação
    if (transactions && transactions.length > 0) {
      generateScenarios()
    }
  }, [transactions, balance])

  const generateScenarios = () => {
    // 1. Calcular despesas médias dos últimos 15 dias
    const today = new Date()
    const recentTransactions = transactions.filter(t => {
      const transactionDate = new Date(t.date)
      const daysDiff = (today.getTime() - transactionDate.getTime()) / (1000 * 60 * 60 * 24)
      return daysDiff <= 15 && t.type === 'expense'
    })

    const totalExpenses = Math.abs(
      recentTransactions.reduce((sum, t) => sum + t.amount, 0)
    )
    const avgDailyExpense = totalExpenses / 15

    // 2. Calcular receitas médias
    const recentIncomes = transactions.filter(t => {
      const transactionDate = new Date(t.date)
      const daysDiff = (today.getTime() - transactionDate.getTime()) / (1000 * 60 * 60 * 24)
      return daysDiff <= 15 && t.type === 'income'
    })

    const totalIncomes = recentIncomes.reduce((sum, t) => sum + t.amount, 0)
    const avgDailyIncome = totalIncomes / 15

    // 3. Gerar cenários automáticos
    const newScenarios: Scenario[] = []

    // Cenário 1: Redução de 10% nos gastos
    const reduction10 = avgDailyExpense * 0.1
    const newExpense10 = avgDailyExpense - reduction10
    const projectedBalance10 = balance + (avgDailyIncome * 30) - (newExpense10 * 30)
    const savings10 = reduction10 * 30

    newScenarios.push({
      name: 'Economia Leve',
      reduction: 10,
      projectedBalance: Math.round(projectedBalance10),
      savings: Math.round(savings10),
      impact: 'Reduzir gastos em 10%'
    })

    // Cenário 2: Redução de 20% nos gastos
    const reduction20 = avgDailyExpense * 0.2
    const newExpense20 = avgDailyExpense - reduction20
    const projectedBalance20 = balance + (avgDailyIncome * 30) - (newExpense20 * 30)
    const savings20 = reduction20 * 30

    newScenarios.push({
      name: 'Economia Moderada',
      reduction: 20,
      projectedBalance: Math.round(projectedBalance20),
      savings: Math.round(savings20),
      impact: 'Reduzir gastos em 20%'
    })

    // Cenário 3: Redução de 30% nos gastos
    const reduction30 = avgDailyExpense * 0.3
    const newExpense30 = avgDailyExpense - reduction30
    const projectedBalance30 = balance + (avgDailyIncome * 30) - (newExpense30 * 30)
    const savings30 = reduction30 * 30

    newScenarios.push({
      name: 'Economia Agressiva',
      reduction: 30,
      projectedBalance: Math.round(projectedBalance30),
      savings: Math.round(savings30),
      impact: 'Reduzir gastos em 30%'
    })

    // Cenário 4: Aumento de 15% na renda (bônus, renda extra)
    const incomeBoost = avgDailyIncome * 0.15
    const newIncome = avgDailyIncome + incomeBoost
    const projectedBalanceBoost = balance + (newIncome * 30) - (avgDailyExpense * 30)
    const extraIncome = incomeBoost * 30

    newScenarios.push({
      name: 'Renda Extra',
      reduction: -15,
      projectedBalance: Math.round(projectedBalanceBoost),
      savings: Math.round(extraIncome),
      impact: 'Aumentar renda em 15%'
    })

    setScenarios(newScenarios)
  }

  if (scenarios.length === 0) {
    return null
  }

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border">
      <CardHeader>
        <CardTitle className="text-foreground flex items-center gap-2">
          <Zap className="w-6 h-6 text-primary" />
          Simulador Automático - Cenários Financeiros
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-primary/80 mb-6">
          Veja automaticamente como diferentes cenários impactariam seu saldo em 30 dias:
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {scenarios.map((scenario, index) => (
            <div 
              key={index}
              className="p-4 bg-secondary/50 border border-border rounded-lg hover:bg-secondary/70 transition-colors"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-foreground font-semibold text-lg">{scenario.name}</h3>
                  <p className="text-primary/70 text-sm">{scenario.impact}</p>
                </div>
                {scenario.reduction > 0 ? (
                  <TrendingDown className="w-5 h-5 text-destructive" />
                ) : (
                  <TrendingUp className="w-5 h-5 text-green-500" />
                )}
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-primary/80 text-sm">Economia/Ganho em 30 dias:</span>
                  <span className={`font-bold ${scenario.savings > 0 ? 'text-green-500' : 'text-primary'}`}>
                    R$ {Math.abs(scenario.savings).toLocaleString('pt-BR')}
                  </span>
                </div>

                <div className="flex justify-between items-center pt-2 border-t border-border">
                  <span className="text-foreground font-semibold">Saldo Previsto:</span>
                  <span className={`text-lg font-bold ${
                    scenario.projectedBalance >= 0 ? 'text-green-500' : 'text-destructive'
                  }`}>
                    R$ {scenario.projectedBalance.toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-primary/10 border border-primary/30 rounded-lg">
          <p className="text-foreground text-sm">
            💡 <strong>Dica:</strong> Estes cenários são calculados automaticamente com base nos seus padrões de gastos e receitas dos últimos 15 dias. Use-os como referência para planejar suas finanças!
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

