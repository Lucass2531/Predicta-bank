import { useState, useEffect } from 'react'
import { LogOut, TrendingUp, TrendingDown, AlertTriangle, DollarSign, Calendar, Zap, Radar, Building2, MoreVertical, Settings as SettingsIcon, HelpCircle, Info } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'

import FinancialSimulator from './FinancialSimulator'
import AnomalyDetector from './AnomalyDetector'
import LifetimeProjector from './LifetimeProjector'
import OpenFinance from './OpenFinance'
import MenuInovador from './MenuInovador'
import '../App.css'

const calculatePredictionLogic = (transactions, balance, avgDailyIncome, avgDailyExpense) => {
  const prediction = []
  let currentBalance = balance
  const today = new Date()
  
  for (let i = 0; i <= 30; i++) {
    const date = new Date(today)
    date.setDate(date.getDate() + i)
    
    currentBalance = balance + (avgDailyIncome * i) - (avgDailyExpense * i)

    prediction.push({
      date: date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      balance: Math.round(currentBalance),
      isToday: i === 0
    })
  }
  return prediction
}

const AIInsight = ({ insight }) => (
  <Card className="bg-card/50 backdrop-blur-sm border-border">
    <CardHeader>
      <CardTitle className="text-foreground flex items-center gap-2">
        <Zap className="w-6 h-6 text-primary" />
        Insight Inteligente
      </CardTitle>
    </CardHeader>
    <CardContent>
      <p className="text-foreground">{insight}</p>
    </CardContent>
  </Card>
)

export default function Dashboard({ user, onLogout }) {
  const [userData, setUserData] = useState(user)
  const [predictionData, setPredictionData] = useState([])
  const [alerts, setAlerts] = useState([])
  const [aiInsight, setAiInsight] = useState("Analisando seus dados para oferecer uma previsão mais precisa...")
  const [activeTab, setActiveTab] = useState('overview')
  

  useEffect(() => {
    const users = JSON.parse(localStorage.getItem('users') || '[]')
    const currentUser = users.find(u => u.id === user.id)
    if (currentUser) {
      setUserData(currentUser)
      calculatePrediction(currentUser)
    }
  }, [user.id])

  const getDailyAverages = (transactions) => {
    const today = new Date()
    const recentTransactions = transactions.filter(t => (today - new Date(t.date)) / (1000 * 60 * 60 * 24) <= 15)

    const avgDailyIncome = recentTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0) / 15
    
    const avgDailyExpense = recentTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + Math.abs(t.amount), 0) / 15
      
    return { avgDailyIncome, avgDailyExpense }
  }

  const calculatePrediction = (currentUser) => {
    const transactions = currentUser.transactions || []
    const balance = currentUser.balance || 0
    const { avgDailyIncome, avgDailyExpense } = getDailyAverages(transactions)

    const prediction = calculatePredictionLogic(transactions, balance, avgDailyIncome, avgDailyExpense)
    setPredictionData(prediction)

    const newAlerts = []
    
    const negativeDay = prediction.find(p => p.balance < 0)
    if (negativeDay) {
      newAlerts.push({
        type: 'danger',
        message: `Atenção! Seu saldo pode ficar negativo em ${negativeDay.date}. Considere reduzir gastos.`,
        icon: AlertTriangle
      })
      setAiInsight(`Atenção: Com base nos seus gastos recentes, você está consumindo R$ ${avgDailyExpense.toFixed(2)} a mais por dia do que ganha.`)
    } else if (balance > 5000 && (avgDailyIncome * 30) > (avgDailyExpense * 30)) {
      setAiInsight("Excelente! Seu fluxo de caixa está positivo. Considere investir o excedente.")
    } else {
      setAiInsight("Seus gastos e receitas estão equilibrados. Continue monitorando de perto.")
    }

    const lowBalanceDay = prediction.find(p => p.balance < 500 && p.balance > 0)
    if (lowBalanceDay && !negativeDay) {
      newAlerts.push({
        type: 'warning',
        message: `Seu saldo pode ficar baixo (R$ ${lowBalanceDay.balance}) em ${lowBalanceDay.date}`,
        icon: TrendingDown
      })
    }

    if (!negativeDay && !lowBalanceDay) {
      newAlerts.push({
        type: 'success',
        message: 'Suas finanças estão no caminho certo! Continue assim.',
        icon: TrendingUp
      })
    }

    setAlerts(newAlerts)
  }

  const handleSimulate = ({ description, change }) => {
    const transactions = userData.transactions || []
    const balance = userData.balance || 0
    
    const { avgDailyIncome, avgDailyExpense } = getDailyAverages(transactions)
    
    let newAvgDailyExpense = avgDailyExpense
    if (description === 'Todos') {
      newAvgDailyExpense = avgDailyExpense * (1 + (change / 100))
    } else {
      const targetExpenses = transactions.filter(t => t.type === 'expense' && t.description === description)
      const avgTargetExpense = targetExpenses.reduce((sum, t) => sum + Math.abs(t.amount), 0) / 15
      
      const changeAmount = avgTargetExpense * (change / 100)
      newAvgDailyExpense = avgDailyExpense + changeAmount
    }
    
    const simulatedPrediction = calculatePredictionLogic(transactions, balance, avgDailyIncome, newAvgDailyExpense)
    
    return { ...userData, predictionData: simulatedPrediction }
  }

  const recentTransactions = [...(userData.transactions || [])].reverse().slice(0, 5)

  const tabs = [
    { id: 'overview', label: 'Visão Geral', icon: DollarSign },
    { id: 'predictions', label: 'Previsões', icon: Calendar },
    { id: 'analysis', label: 'Análise', icon: Radar },
    { id: 'openfinance', label: 'Open Finance', icon: Building2 }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card/50 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-primary p-2 rounded-lg">
              <TrendingUp className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">Predicta Bank</h1>
              <p className="text-sm text-primary">Olá, {userData.name}!</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <MenuInovador onLogout={onLogout} />
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-card/30 backdrop-blur-sm border-b border-border sticky top-0 z-10">
        <div className="container mx-auto px-4">
          <div className="flex gap-2 overflow-x-auto py-3">
            {tabs.map(tab => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
                    activeTab === tab.id
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary/50 text-foreground hover:bg-secondary'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        
        {/* VISÃO GERAL */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Balance Card */}
            <Card className="bg-card/50 backdrop-blur-sm border-border">
              <CardHeader>
                <CardTitle className="text-foreground flex items-center gap-2">
                  <DollarSign className="w-6 h-6" />
                  Saldo Atual
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-5xl font-bold text-foreground mb-2">
                  R$ {userData.balance?.toLocaleString('pt-BR')}
                </div>
                <p className="text-primary">Atualizado agora</p>
              </CardContent>
            </Card>

            {/* AI Insight Card */}
            <AIInsight insight={aiInsight} />

            {/* Alerts */}
            {alerts.length > 0 && (
              <div className="space-y-3">
                {alerts.map((alert, index) => (
                  <Card 
                    key={index}
                    className={`border-2 ${
                      alert.type === 'danger' ? 'bg-destructive/20 border-destructive/50' :
                      alert.type === 'warning' ? 'bg-yellow-500/20 border-yellow-400/50' :
                      'bg-green-500/20 border-green-400/50'
                    } backdrop-blur-lg`}
                  >
                    <CardContent className="p-4 flex items-center gap-3">
                      <alert.icon className={`w-6 h-6 ${
                        alert.type === 'danger' ? 'text-destructive' :
                        alert.type === 'warning' ? 'text-yellow-300' :
                        'text-green-300'
                      }`} />
                      <p className="text-foreground font-semibold">{alert.message}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Recent Transactions */}
            <Card className="bg-card/50 backdrop-blur-sm border-border">
              <CardHeader>
                <CardTitle className="text-foreground">Transações Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {recentTransactions.length > 0 ? (
                    recentTransactions.map(t => (
                      <div key={t.id} className="flex justify-between items-center p-2 bg-secondary/50 rounded-lg">
                        <span className="text-foreground">{t.description}</span>
                        <span className={`font-bold ${t.type === 'income' ? 'text-green-500' : 'text-destructive'}`}>
                          {t.type === 'income' ? '+' : '-'} R$ {Math.abs(t.amount).toLocaleString('pt-BR')}
                        </span>
                      </div>
                    ))
                  ) : (
                    <p className="text-primary/80">Nenhuma transação registrada</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* PREVISÕES */}
        {activeTab === 'predictions' && (
          <div className="space-y-6">
            {/* Prediction Chart */}
            <Card className="bg-card/50 backdrop-blur-sm border-border">
              <CardHeader>
                <CardTitle className="text-foreground flex items-center gap-2">
                  <Calendar className="w-6 h-6" />
                  Previsão de Saldo - Próximos 30 Dias
                </CardTitle>
                <CardDescription className="text-primary">
                  Baseado nos seus padrões de gastos e receitas (Média Ponderada)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={predictionData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333333" />
                      <XAxis 
                        dataKey="date" 
                        stroke="#64B5F6"
                        tick={{ fill: '#64B5F6', fontSize: 12 }}
                      />
                      <YAxis 
                        stroke="#64B5F6"
                        tick={{ fill: '#64B5F6', fontSize: 12 }}
                        tickFormatter={(value) => `R$ ${value}`}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1a1a1a', 
                          border: '2px solid #64B5F6',
                          borderRadius: '8px',
                          color: '#ffffff',
                          padding: '10px'
                        }}
                        formatter={(value) => [`R$ ${value}`, 'Saldo Previsto']}
                      />
                      <ReferenceLine y={0} stroke="#FF6B6B" strokeDasharray="5 5" strokeWidth={2} />
                      <Line 
                        type="monotone" 
                        dataKey="balance" 
                        stroke="#64B5F6" 
                        strokeWidth={3}
                        dot={(props) => {
                          const { cx, cy, payload } = props
                          if (payload.isToday) {
                            return (
                              <circle 
                                cx={cx} 
                                cy={cy} 
                                r={6} 
                                fill="#64B5F6" 
                                stroke="#ffffff" 
                                strokeWidth={2}
                              />
                            )
                          }
                          if (payload.balance < 0) {
                            return (
                              <circle 
                                cx={cx} 
                                cy={cy} 
                                r={5} 
                                fill="#FF6B6B" 
                                stroke="#ffffff" 
                                strokeWidth={1}
                              />
                            )
                          }
                          return null
                        }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Financial Simulator */}
            <FinancialSimulator 
              transactions={userData.transactions || []}
              balance={userData.balance || 0}
              onSimulate={handleSimulate}
            />

            {/* Lifetime Projector */}
            <LifetimeProjector 
              transactions={userData.transactions || []}
              balance={userData.balance || 0}
            />
          </div>
        )}

        {/* ANÁLISE */}
        {activeTab === 'analysis' && (
          <div className="space-y-6">
            {/* Anomaly Detector */}
            <AnomalyDetector transactions={userData.transactions || []} />
          </div>
        )}

        {/* OPEN FINANCE */}
        {activeTab === 'openfinance' && (
          <OpenFinance 
            onImportTransactions={(importedTransactions) => {
              const updatedUser = {
                ...userData,
                transactions: [...(userData.transactions || []), ...importedTransactions]
              }
              setUserData(updatedUser)
              
              const users = JSON.parse(localStorage.getItem('users') || '[]')
              const updatedUsers = users.map(u => u.id === updatedUser.id ? updatedUser : u)
              localStorage.setItem('users', JSON.stringify(updatedUsers))
              
              calculatePrediction(updatedUser)
            }}
          />
        )}

        {/* SETTINGS */}


      </div>
    </div>
  )
}

