import { useState } from 'react';
import { MoreVertical, Settings as SettingsIcon, HelpCircle, LogOut, Zap, TrendingUp, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';

// Componente que representa o conteúdo da Guia Configurações
const SettingsContent = () => (
  <div className="p-4 space-y-3">
    <h4 className="text-sm font-semibold">Configurações de Conta</h4>
    <Button variant="ghost" className="w-full justify-start text-sm px-2">
      <Zap className="mr-2 h-4 w-4" /> Gerenciar Biometria
    </Button>
    <Button variant="ghost" className="w-full justify-start text-sm px-2">
      <TrendingUp className="mr-2 h-4 w-4" /> Limites de Transação
    </Button>
    <Button variant="ghost" className="w-full justify-start text-sm px-2">
      <TrendingDown className="mr-2 h-4 w-4" /> Preferências de Notificação
    </Button>
    <Separator className="my-2" />
    <h4 className="text-sm font-semibold">Aparência</h4>
    <Button variant="ghost" className="w-full justify-start text-sm px-2">
      <SettingsIcon className="mr-2 h-4 w-4" /> Mudar Tema (Claro/Escuro)
    </Button>
  </div>
);

// Componente que representa o conteúdo da Guia Ajuda
const HelpContent = ({ onLogout }) => (
  <div className="p-4 space-y-3">
    <h4 className="text-sm font-semibold">Suporte</h4>
    <Button variant="ghost" className="w-full justify-start text-sm px-2">
      <HelpCircle className="mr-2 h-4 w-4" /> Perguntas Frequentes
    </Button>
    <Button variant="ghost" className="w-full justify-start text-sm px-2">
      <LogOut className="mr-2 h-4 w-4" /> Fale Conosco
    </Button>
    <Separator className="my-2" />
    <DropdownMenuItem onClick={onLogout} className="text-red-500 cursor-pointer">
      <LogOut className="mr-2 h-4 w-4" /> Sair
    </DropdownMenuItem>
  </div>
);

export default function MenuInovador({ onLogout }) {
  const [open, setOpen] = useState(false);

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="text-foreground">
          <MoreVertical className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80 p-0">
        <Tabs defaultValue="settings">
          <TabsList className="grid w-full grid-cols-2 h-10 rounded-b-none">
            <TabsTrigger value="settings" className="flex items-center gap-1">
              <SettingsIcon className="h-4 w-4" /> Configurações
            </TabsTrigger>
            <TabsTrigger value="help" className="flex items-center gap-1">
              <HelpCircle className="h-4 w-4" /> Ajuda
            </TabsTrigger>
          </TabsList>
          <TabsContent value="settings" className="m-0">
            <SettingsContent />
          </TabsContent>
          <TabsContent value="help" className="m-0">
            <HelpContent onLogout={onLogout} />
          </TabsContent>
        </Tabs>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
