import { useState, useEffect } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { TrendingUp, Calendar } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

interface Projection {
  year: number
  balance: number
  totalSaved: number
  label: string
}

export default function LifetimeProjector({ transactions, balance }) {
  const [projections, setProjections] = useState<Projection[]>([])

  useEffect(() => {
    if (transactions && transactions.length > 0) {
      calculateProjections()
    }
  }, [transactions, balance])

  const calculateProjections = () => {
    const today = new Date()

    // 1. Calcular receitas e despesas médias diárias
    const recentTransactions = transactions.filter(t => {
      const transactionDate = new Date(t.date)
      const daysDiff = (today.getTime() - transactionDate.getTime()) / (1000 * 60 * 60 * 24)
      return daysDiff <= 30
    })

    const totalIncome = recentTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0)

    const totalExpense = Math.abs(
      recentTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0)
    )

    const avgDailyIncome = totalIncome / 30
    const avgDailyExpense = totalExpense / 30
    const dailyNet = avgDailyIncome - avgDailyExpense

    // 2. Gerar projeções para 1, 5 e 10 anos
    const newProjections: Projection[] = []

    // Projeção 1 ano
    const balance1Year = balance + (dailyNet * 365)
    newProjections.push({
      year: 1,
      balance: Math.round(balance1Year),
      totalSaved: Math.round(dailyNet * 365),
      label: '1 Ano'
    })

    // Projeção 5 anos
    const balance5Years = balance + (dailyNet * 365 * 5)
    newProjections.push({
      year: 5,
      balance: Math.round(balance5Years),
      totalSaved: Math.round(dailyNet * 365 * 5),
      label: '5 Anos'
    })

    // Projeção 10 anos
    const balance10Years = balance + (dailyNet * 365 * 10)
    newProjections.push({
      year: 10,
      balance: Math.round(balance10Years),
      totalSaved: Math.round(dailyNet * 365 * 10),
      label: '10 Anos'
    })

    setProjections(newProjections)
  }

  if (projections.length === 0) {
    return null
  }

  const chartData = projections.map(p => ({
    name: p.label,
    'Saldo Previsto': p.balance,
    'Total Economizado': p.totalSaved
  }))

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border">
      <CardHeader>
        <CardTitle className="text-foreground flex items-center gap-2">
          <Calendar className="w-6 h-6 text-primary" />
          🔮 Simulador de Vida Financeira
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <p className="text-primary/80">
          Veja como sua situação financeira evoluirá nos próximos 1, 5 e 10 anos:
        </p>

        {/* Gráfico de Projeção */}
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333333" />
              <XAxis 
                dataKey="name" 
                stroke="#64B5F6"
                tick={{ fill: '#64B5F6', fontSize: 12 }}
              />
              <YAxis 
                stroke="#64B5F6"
                tick={{ fill: '#64B5F6', fontSize: 12 }}
                tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1a1a1a', 
                  border: '2px solid #64B5F6',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
                formatter={(value) => `R$ ${Number(value).toLocaleString('pt-BR')}`}
              />
              <Legend 
                wrapperStyle={{ color: '#64B5F6' }}
                contentStyle={{ color: '#64B5F6' }}
              />
              <Bar dataKey="Saldo Previsto" fill="#64B5F6" radius={[8, 8, 0, 0]} />
              <Bar dataKey="Total Economizado" fill="#4CAF50" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Cards de Projeção Detalhada */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {projections.map((projection, index) => (
            <div
              key={index}
              className="p-4 bg-secondary/50 border border-border rounded-lg"
            >
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-foreground font-semibold text-lg">{projection.label}</h3>
                <TrendingUp className="w-5 h-5 text-primary" />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-primary/80 text-sm">Saldo Previsto:</span>
                  <span className={`font-bold text-lg ${
                    projection.balance >= 0 ? 'text-green-500' : 'text-destructive'
                  }`}>
                    R$ {projection.balance.toLocaleString('pt-BR')}
                  </span>
                </div>

                <div className="flex justify-between items-center pt-2 border-t border-border">
                  <span className="text-primary/80 text-sm">Total Economizado:</span>
                  <span className="font-bold text-green-500">
                    R$ {projection.totalSaved.toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Insights */}
        <div className="p-4 bg-primary/10 border border-primary/30 rounded-lg space-y-2">
          <p className="text-foreground text-sm">
            💡 <strong>Como funciona:</strong> Esta projeção usa seus padrões atuais de renda e despesa para estimar sua situação financeira futura.
          </p>
          <p className="text-foreground text-sm">
            📊 <strong>Nota:</strong> As projeções assumem que seus padrões de renda e despesa permanecerão consistentes. Mudanças significativas podem alterar estes resultados.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

