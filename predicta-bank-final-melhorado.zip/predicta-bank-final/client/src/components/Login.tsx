import { useState, useEffect } from 'react'
import { TrendingUp, Mail, Lock, User, Fingerprint } from 'lucide-react'
import { isBiometricAvailable, authenticateWithBiometric, registerBiometric, getSavedBiometricData, saveBiometricData, getBiometricType } from '@/lib/biometricAuth'
import '../App.css'

export default function Login({ onLogin }) {
  const [isSignUp, setIsSignUp] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  })
  const [error, setError] = useState('')
  const [biometricAvailable, setBiometricAvailable] = useState(false)
  const [biometricLoading, setBiometricLoading] = useState(false)
  const [savedBiometric, setSavedBiometric] = useState(null)
  const [biometricType, setBiometricType] = useState('Biometria')

  // Verificar disponibilidade de biometria ao montar o componente
  useEffect(() => {
    checkBiometricAvailability()
    checkSavedBiometric()
  }, [])

  const checkBiometricAvailability = async () => {
    const available = await isBiometricAvailable()
    setBiometricAvailable(available)
    if (available) {
      setBiometricType(getBiometricType())
    }
  }

  const checkSavedBiometric = () => {
    try {
      const saved = localStorage.getItem('biometricUser')
      if (saved) {
        setSavedBiometric(JSON.parse(saved))
      }
    } catch (err) {
      console.log('Erro ao verificar biometria salva:', err)
    }
  }

  const handleBiometricLogin = async () => {
    setBiometricLoading(true)
    setError('')

    try {
      if (!savedBiometric) {
        setError('Nenhuma biometria registrada. Por favor, faça login com email/senha primeiro.')
        setBiometricLoading(false)
        return
      }

      // Usar API nativa de biometria do celular
      const result = await authenticateWithBiometric(savedBiometric.credentialId)

      if (!result) {
        setError('Falha na autenticação biométrica. Tente novamente.')
        setBiometricLoading(false)
        return
      }

      // Recuperar usuário do localStorage
      const users = JSON.parse(localStorage.getItem('users') || '[]')
      const user = users.find(u => u.id === savedBiometric.userId)

      if (user) {
        onLogin(user)
      window.location.href = '/dashboard'
      } else {
        setError('Usuário não encontrado. Por favor, faça login novamente.')
      }
    } catch (err) {
      setError('Erro na autenticação biométrica. Tente novamente.')
      console.error('Erro biométrico:', err)
    } finally {
      setBiometricLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (isSignUp) {
      // Sign up logic
      if (!formData.name || !formData.email || !formData.password) {
        setError('Por favor, preencha todos os campos')
        return
      }

      // Get existing users
      const users = JSON.parse(localStorage.getItem('users') || '[]')
      
      // Check if email already exists
      if (users.find(u => u.email === formData.email)) {
        setError('Este e-mail já está cadastrado')
        return
      }

      // Create new user
      const newUser = {
        id: Date.now(),
        name: formData.name,
        email: formData.email,
        password: formData.password,
        balance: 5000, // Initial balance
        transactions: [
          { id: 1, date: new Date().toISOString(), description: 'Salário', amount: 5000, type: 'income', category: 'Trabalho' },
          { id: 2, date: new Date(Date.now() - 86400000).toISOString(), description: 'Aluguel', amount: -1500, type: 'expense', category: 'Moradia' },
          { id: 3, date: new Date(Date.now() - 172800000).toISOString(), description: 'Supermercado', amount: -450, type: 'expense', category: 'Alimentação' }
        ]
      }

      users.push(newUser)
      localStorage.setItem('users', JSON.stringify(users))
      
      // Registrar biometria se disponível
      if (biometricAvailable) {
        const biometricData = await registerBiometric(newUser.id, newUser.email, newUser.name)
        if (biometricData) {
          saveBiometricData(biometricData)
        }
      }
      
      onLogin(newUser)
      window.location.href = '/dashboard'
    } else {
      // Login logic
      if (!formData.email || !formData.password) {
        setError('Por favor, preencha e-mail e senha')
        return
      }

      const users = JSON.parse(localStorage.getItem('users') || '[]')
      const user = users.find(u => u.email === formData.email && u.password === formData.password)

      if (!user) {
        setError('E-mail ou senha incorretos')
        return
      }

      // Registrar biometria se disponível
      if (biometricAvailable) {
        const biometricData = await registerBiometric(user.id, user.email, user.name)
        if (biometricData) {
          saveBiometricData(biometricData)
        }
      }

      onLogin(user)
      window.location.href = '/dashboard'
    }
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-card/50 backdrop-blur-lg border border-border rounded-xl p-8 shadow-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-primary p-3 rounded-full">
              <TrendingUp className="w-12 h-12 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-3xl font-bold mb-2 text-foreground">
            Predicta Bank
          </h1>
          <p className="text-primary text-lg">
            O Waze das Suas Finanças
          </p>
        </div>

        {/* Biometric Login Button */}
        {biometricAvailable && savedBiometric && !isSignUp && (
          <div className="mb-6">
            <button
              type="button"
              onClick={handleBiometricLogin}
              disabled={biometricLoading}
              className="w-full py-3 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-semibold text-lg rounded-lg border-none cursor-pointer transition-opacity hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Fingerprint className="w-5 h-5" />
              {biometricLoading ? 'Autenticando...' : 'Entrar com Impressão Digital'}
            </button>
            <div className="flex items-center gap-3 my-4">
              <div className="flex-1 h-px bg-border"></div>
              <span className="text-primary/70 text-sm">ou</span>
              <div className="flex-1 h-px bg-border"></div>
            </div>
            <p className="text-primary/70 text-xs text-center mt-2">Usando {biometricType}</p>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {isSignUp && (
            <div>
              <label htmlFor="name" className="block text-foreground mb-1 text-sm font-medium">
                Nome
              </label>
              <div className="relative">
                <User className="absolute left-3 top-3 w-4 h-4 text-primary" />
                <input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Seu nome"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-lg text-foreground text-base outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </div>
            </div>
          )}
          
          <div>
            <label htmlFor="email" className="block text-foreground mb-1 text-sm font-medium">
              E-mail
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 w-4 h-4 text-primary" />
              <input
                id="email"
                name="email"
                type="email"
                placeholder="seu@email.com"
                value={formData.email}
                onChange={handleChange}
                className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-lg text-foreground text-base outline-none focus:ring-2 focus:ring-primary focus:border-primary"
              />
            </div>
          </div>

          <div>
            <label htmlFor="password" className="block text-foreground mb-1 text-sm font-medium">
              Senha
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-4 h-4 text-primary" />
              <input
                id="password"
                name="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={handleChange}
                className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-lg text-foreground text-base outline-none focus:ring-2 focus:ring-primary focus:border-primary"
              />
            </div>
          </div>

          {error && (
            <div className="bg-destructive/20 border border-destructive/30 text-destructive-foreground p-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <button 
            type="submit"
            className="w-full py-3 bg-primary text-primary-foreground font-semibold text-lg rounded-lg border-none cursor-pointer transition-opacity hover:opacity-90"
          >
            {isSignUp ? 'Criar Conta' : 'Entrar'}
          </button>

          <div className="text-center">
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp)
                setError('')
                setFormData({ name: '', email: '', password: '' })
              }}
              className="text-primary text-sm bg-transparent border-none cursor-pointer underline hover:text-primary/80"
            >
              {isSignUp ? 'Já tem uma conta? Faça login' : 'Não tem uma conta? Cadastre-se'}
            </button>
          </div>
        </form>

        {/* Biometric Info */}
        {biometricAvailable && (
          <div className="mt-6 p-3 bg-primary/10 border border-primary/30 rounded-lg text-center">
            <p className="text-primary text-xs">
              ✓ {biometricType} disponível
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

