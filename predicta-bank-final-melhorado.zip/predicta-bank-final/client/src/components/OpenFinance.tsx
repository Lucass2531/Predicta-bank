import { useState } from 'react'
import { Building2, Link2, CheckCircle2, AlertCircle, RefreshCw, TrendingUp, ArrowDownCircle, ArrowUpCircle } from 'lucide-react'

interface Bank {
  id: string
  name: string
  logo: string
  connected: boolean
  lastSync?: string
  accounts?: BankAccount[]
}

interface BankAccount {
  id: string
  type: string
  balance: number
  transactions: Transaction[]
}

interface Transaction {
  id: string
  date: string
  description: string
  amount: number
  type: 'income' | 'expense'
}

export default function OpenFinance({ onImportTransactions }: { onImportTransactions: (transactions: Transaction[]) => void }) {
  const [banks, setBanks] = useState<Bank[]>([
    {
      id: 'nubank',
      name: 'Nubank',
      logo: '💜',
      connected: false
    },
    {
      id: 'itau',
      name: 'Itaú',
      logo: '🧡',
      connected: false
    },
    {
      id: 'bradesco',
      name: 'Bradesco',
      logo: '❤️',
      connected: false
    },
    {
      id: 'santander',
      name: 'Santander',
      logo: '🔴',
      connected: false
    },
    {
      id: 'bb',
      name: 'Banco do Brasil',
      logo: '💛',
      connected: false
    },
    {
      id: 'caixa',
      name: 'Caixa Econômica',
      logo: '🔵',
      connected: false
    },
    {
      id: 'inter',
      name: 'Banco Inter',
      logo: '🧡',
      connected: false
    },
    {
      id: 'c6',
      name: 'C6 Bank',
      logo: '⚫',
      connected: false
    }
  ])

  const [connecting, setConnecting] = useState<string | null>(null)
  const [syncing, setSyncing] = useState<string | null>(null)

  const connectBank = async (bankId: string) => {
    setConnecting(bankId)

    // Simular conexão com banco (em produção, usaria OAuth2 do Open Finance)
    await new Promise(resolve => setTimeout(resolve, 2000))

    // Gerar transações simuladas
    const mockTransactions: Transaction[] = [
      { id: `${bankId}_1`, date: new Date().toISOString(), description: 'Salário', amount: 5000, type: 'income' },
      { id: `${bankId}_2`, date: new Date(Date.now() - 86400000).toISOString(), description: 'Supermercado', amount: -350, type: 'expense' },
      { id: `${bankId}_3`, date: new Date(Date.now() - 172800000).toISOString(), description: 'Restaurante', amount: -120, type: 'expense' },
      { id: `${bankId}_4`, date: new Date(Date.now() - 259200000).toISOString(), description: 'Uber', amount: -45, type: 'expense' },
      { id: `${bankId}_5`, date: new Date(Date.now() - 345600000).toISOString(), description: 'Freelance', amount: 1500, type: 'income' }
    ]

    const mockAccount: BankAccount = {
      id: `${bankId}_acc_1`,
      type: 'Conta Corrente',
      balance: 3500,
      transactions: mockTransactions
    }

    setBanks(prev => prev.map(bank => 
      bank.id === bankId 
        ? { ...bank, connected: true, lastSync: new Date().toISOString(), accounts: [mockAccount] }
        : bank
    ))

    // Importar transações para o dashboard
    onImportTransactions(mockTransactions)

    setConnecting(null)
  }

  const disconnectBank = (bankId: string) => {
    setBanks(prev => prev.map(bank => 
      bank.id === bankId 
        ? { ...bank, connected: false, lastSync: undefined, accounts: undefined }
        : bank
    ))
  }

  const syncBank = async (bankId: string) => {
    setSyncing(bankId)

    // Simular sincronização
    await new Promise(resolve => setTimeout(resolve, 1500))

    setBanks(prev => prev.map(bank => 
      bank.id === bankId 
        ? { ...bank, lastSync: new Date().toISOString() }
        : bank
    ))

    setSyncing(null)
  }

  const connectedBanks = banks.filter(b => b.connected)
  const totalBalance = connectedBanks.reduce((sum, bank) => {
    return sum + (bank.accounts?.reduce((acc, account) => acc + account.balance, 0) || 0)
  }, 0)

  const totalIncome = connectedBanks.reduce((sum, bank) => {
    return sum + (bank.accounts?.reduce((acc, account) => {
      return acc + account.transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0)
    }, 0) || 0)
  }, 0)

  const totalExpense = connectedBanks.reduce((sum, bank) => {
    return sum + (bank.accounts?.reduce((acc, account) => {
      return acc + Math.abs(account.transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0))
    }, 0) || 0)
  }, 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <Building2 className="w-8 h-8 text-primary" />
          <div>
            <h2 className="text-2xl font-bold text-foreground">Open Finance</h2>
            <p className="text-muted-foreground text-sm">Conecte suas contas bancárias e importe transações automaticamente</p>
          </div>
        </div>

        {connectedBanks.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <div className="bg-primary/10 border border-primary/30 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                <span className="text-muted-foreground text-sm">Saldo Total</span>
              </div>
              <p className="text-2xl font-bold text-foreground">
                R$ {totalBalance.toFixed(2)}
              </p>
            </div>

            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <ArrowUpCircle className="w-5 h-5 text-green-500" />
                <span className="text-muted-foreground text-sm">Receitas</span>
              </div>
              <p className="text-2xl font-bold text-green-500">
                R$ {totalIncome.toFixed(2)}
              </p>
            </div>

            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <ArrowDownCircle className="w-5 h-5 text-red-500" />
                <span className="text-muted-foreground text-sm">Despesas</span>
              </div>
              <p className="text-2xl font-bold text-red-500">
                R$ {totalExpense.toFixed(2)}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Connected Banks */}
      {connectedBanks.length > 0 && (
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Bancos Conectados</h3>
          <div className="space-y-3">
            {connectedBanks.map(bank => (
              <div key={bank.id} className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{bank.logo}</span>
                    <div>
                      <h4 className="font-semibold text-foreground">{bank.name}</h4>
                      <p className="text-xs text-muted-foreground">
                        Última sincronização: {bank.lastSync ? new Date(bank.lastSync).toLocaleString('pt-BR') : 'Nunca'}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => syncBank(bank.id)}
                      disabled={syncing === bank.id}
                      className="px-3 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 disabled:opacity-50 flex items-center gap-2"
                    >
                      <RefreshCw className={`w-4 h-4 ${syncing === bank.id ? 'animate-spin' : ''}`} />
                      {syncing === bank.id ? 'Sincronizando...' : 'Sincronizar'}
                    </button>
                    <button
                      onClick={() => disconnectBank(bank.id)}
                      className="px-3 py-2 bg-destructive text-destructive-foreground rounded-lg text-sm font-medium hover:opacity-90"
                    >
                      Desconectar
                    </button>
                  </div>
                </div>

                {bank.accounts && bank.accounts.length > 0 && (
                  <div className="space-y-2">
                    {bank.accounts.map(account => (
                      <div key={account.id} className="bg-background/50 rounded-lg p-3">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-muted-foreground">{account.type}</span>
                          <span className="text-lg font-bold text-foreground">
                            R$ {account.balance.toFixed(2)}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {account.transactions.length} transações importadas
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Available Banks */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Bancos Disponíveis</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {banks.filter(b => !b.connected).map(bank => (
            <div key={bank.id} className="bg-card border border-border rounded-lg p-4 hover:border-primary/50 transition-colors">
              <div className="flex flex-col items-center text-center gap-3">
                <span className="text-4xl">{bank.logo}</span>
                <h4 className="font-semibold text-foreground">{bank.name}</h4>
                <button
                  onClick={() => connectBank(bank.id)}
                  disabled={connecting === bank.id}
                  className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {connecting === bank.id ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Conectando...
                    </>
                  ) : (
                    <>
                      <Link2 className="w-4 h-4" />
                      Conectar
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Info */}
      <div className="bg-primary/10 border border-primary/30 rounded-lg p-4">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
          <div className="text-sm text-foreground">
            <p className="font-semibold mb-1">Segurança e Privacidade</p>
            <p className="text-muted-foreground">
              Suas credenciais bancárias são criptografadas e nunca são armazenadas em nossos servidores. 
              Utilizamos o padrão Open Finance do Banco Central para garantir máxima segurança.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

