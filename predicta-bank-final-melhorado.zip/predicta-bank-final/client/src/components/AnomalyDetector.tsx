import { useState, useEffect } from 'react'
import { AlertTriangle, TrendingUp, Zap } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

interface Anomaly {
  type: 'spike' | 'pattern' | 'frequency'
  description: string
  severity: 'low' | 'medium' | 'high'
  amount?: number
  category?: string
}

export default function AnomalyDetector({ transactions }) {
  const [anomalies, setAnomalies] = useState<Anomaly[]>([])

  useEffect(() => {
    if (transactions && transactions.length > 0) {
      detectAnomalies()
    }
  }, [transactions])

  const detectAnomalies = () => {
    const detected: Anomaly[] = []
    const today = new Date()

    // 1. Detectar PICOS DE GASTO (spike detection)
    const last30Days = transactions.filter(t => {
      const transactionDate = new Date(t.date)
      const daysDiff = (today.getTime() - transactionDate.getTime()) / (1000 * 60 * 60 * 24)
      return daysDiff <= 30 && t.type === 'expense'
    })

    if (last30Days.length > 0) {
      const amounts = last30Days.map(t => Math.abs(t.amount))
      const avgAmount = amounts.reduce((a, b) => a + b, 0) / amounts.length
      const maxAmount = Math.max(...amounts)
      const stdDev = Math.sqrt(
        amounts.reduce((sq, n) => sq + Math.pow(n - avgAmount, 2), 0) / amounts.length
      )

      // Se um gasto é 2.5x o desvio padrão acima da média
      if (maxAmount > avgAmount + 2.5 * stdDev) {
        const anomalyTransaction = last30Days.find(t => Math.abs(t.amount) === maxAmount)
        detected.push({
          type: 'spike',
          description: `⚠️ Gasto anormalmente alto detectado: R$ ${maxAmount.toLocaleString('pt-BR')} em "${anomalyTransaction?.description}"`,
          severity: maxAmount > avgAmount + 3.5 * stdDev ? 'high' : 'medium',
          amount: maxAmount,
          category: anomalyTransaction?.description
        })
      }
    }

    // 2. Detectar MUDANÇAS DE PADRÃO (pattern change)
    const last15Days = transactions.filter(t => {
      const transactionDate = new Date(t.date)
      const daysDiff = (today.getTime() - transactionDate.getTime()) / (1000 * 60 * 60 * 24)
      return daysDiff <= 15 && t.type === 'expense'
    })

    const previous15Days = transactions.filter(t => {
      const transactionDate = new Date(t.date)
      const daysDiff = (today.getTime() - transactionDate.getTime()) / (1000 * 60 * 60 * 24)
      return daysDiff > 15 && daysDiff <= 30 && t.type === 'expense'
    })

    if (last15Days.length > 0 && previous15Days.length > 0) {
      const currentTotal = Math.abs(last15Days.reduce((sum, t) => sum + t.amount, 0))
      const previousTotal = Math.abs(previous15Days.reduce((sum, t) => sum + t.amount, 0))

      const changePercent = ((currentTotal - previousTotal) / previousTotal) * 100

      if (changePercent > 40) {
        detected.push({
          type: 'pattern',
          description: `📈 Seus gastos aumentaram ${Math.round(changePercent)}% nos últimos 15 dias comparado ao período anterior`,
          severity: changePercent > 60 ? 'high' : 'medium'
        })
      } else if (changePercent < -40) {
        detected.push({
          type: 'pattern',
          description: `📉 Seus gastos diminuíram ${Math.round(Math.abs(changePercent))}% - Ótimo trabalho!`,
          severity: 'low'
        })
      }
    }

    // 3. Detectar FREQUÊNCIA ANORMAL (frequency anomaly)
    const categoryFrequency: { [key: string]: number } = {}
    last30Days.forEach(t => {
      categoryFrequency[t.description] = (categoryFrequency[t.description] || 0) + 1
    })

    const avgFrequency = Object.values(categoryFrequency).reduce((a, b) => a + b, 0) / Object.keys(categoryFrequency).length
    const stdDevFreq = Math.sqrt(
      Object.values(categoryFrequency).reduce((sq, n) => sq + Math.pow(n - avgFrequency, 2), 0) / Object.keys(categoryFrequency).length
    )

    Object.entries(categoryFrequency).forEach(([category, freq]) => {
      if (freq > avgFrequency + 2 * stdDevFreq) {
        detected.push({
          type: 'frequency',
          description: `🔄 Você fez ${freq} transações em "${category}" nos últimos 30 dias - Frequência anormalmente alta`,
          severity: freq > avgFrequency + 3 * stdDevFreq ? 'high' : 'medium',
          category
        })
      }
    })

    setAnomalies(detected)
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-destructive/20 border-destructive/50'
      case 'medium':
        return 'bg-yellow-500/20 border-yellow-400/50'
      case 'low':
        return 'bg-green-500/20 border-green-400/50'
      default:
        return 'bg-primary/20 border-primary/50'
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <AlertTriangle className="w-5 h-5 text-destructive" />
      case 'medium':
        return <TrendingUp className="w-5 h-5 text-yellow-400" />
      case 'low':
        return <Zap className="w-5 h-5 text-green-400" />
      default:
        return <Zap className="w-5 h-5 text-primary" />
    }
  }

  if (anomalies.length === 0) {
    return null
  }

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border">
      <CardHeader>
        <CardTitle className="text-foreground flex items-center gap-2">
          <Zap className="w-6 h-6 text-primary" />
          🎯 Radar de Gastos Suspeitos
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-primary/80 mb-4">
          Análise inteligente detectou {anomalies.length} padrão(ões) anormal(is) nos seus gastos:
        </p>

        <div className="space-y-3">
          {anomalies.map((anomaly, index) => (
            <div
              key={index}
              className={`p-4 border-2 rounded-lg flex items-start gap-3 ${getSeverityColor(anomaly.severity)}`}
            >
              <div className="mt-1">
                {getSeverityIcon(anomaly.severity)}
              </div>
              <div className="flex-1">
                <p className="text-foreground font-semibold">{anomaly.description}</p>
                {anomaly.severity === 'high' && (
                  <p className="text-sm text-destructive mt-1 font-medium">
                    ⚡ Recomendação: Revise este gasto e considere reduzir
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-primary/10 border border-primary/30 rounded-lg">
          <p className="text-foreground text-sm">
            💡 <strong>Como funciona:</strong> O Radar analisa seus padrões de gastos para detectar anomalias como picos de gasto, mudanças drásticas de padrão e frequências anormais. Use essas informações para tomar decisões financeiras melhores!
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

