import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { classifyTransaction, detectTransactionType } from '@/lib/categoryClassifier'

export default function AddTransaction({ onAdd, onCancel }) {
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    type: 'expense',
    category: 'Outros'
  })

  const [suggestedCategory, setSuggestedCategory] = useState('Outros')
  const [suggestedType, setSuggestedType] = useState('expense')

  // Atualiza a categoria sugerida quando a descrição muda
  useEffect(() => {
    if (formData.description.length > 2) {
      const autoCategory = classifyTransaction(formData.description)
      const autoType = detectTransactionType(formData.description)
      
      setSuggestedCategory(autoCategory)
      setSuggestedType(autoType)
      
      // Auto-atualiza o tipo se detectou receita
      if (autoType === 'income' && formData.type === 'expense') {
        setFormData(prev => ({
          ...prev,
          type: 'income',
          category: autoCategory
        }))
      } else {
        setFormData(prev => ({
          ...prev,
          category: autoCategory
        }))
      }
    }
  }, [formData.description])

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (!formData.description || !formData.amount) {
      return
    }

    const transaction = {
      description: formData.description,
      amount: formData.type === 'expense' ? -Math.abs(parseFloat(formData.amount)) : Math.abs(parseFloat(formData.amount)),
      type: formData.type,
      category: formData.category
    }

    onAdd(transaction)
  }

  const categories = [
    'Alimentação',
    'Transporte',
    'Moradia',
    'Saúde',
    'Educação',
    'Compras',
    'Lazer',
    'Trabalho',
    'Investimento',
    'Seguro',
    'Outros'
  ]

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="description" className="text-foreground">
          Descrição 
          <span className="text-primary/70 text-sm ml-2">
            (Digite para auto-categorizar)
          </span>
        </Label>
        <Input
          id="description"
          type="text"
          placeholder="Ex: Salário, Aluguel, Supermercado"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="bg-input border-border text-foreground placeholder:text-muted-foreground"
        />
        {formData.description.length > 2 && (
          <p className="text-primary/80 text-sm">
            💡 Categoria sugerida: <strong>{suggestedCategory}</strong> | 
            Tipo: <strong>{suggestedType === 'income' ? 'Receita' : 'Despesa'}</strong>
          </p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount" className="text-foreground">Valor (R$)</Label>
        <Input
          id="amount"
          type="number"
          step="0.01"
          placeholder="0.00"
          value={formData.amount}
          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          className="bg-input border-border text-foreground placeholder:text-muted-foreground"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="type" className="text-foreground">Tipo</Label>
        <Select 
          value={formData.type} 
          onValueChange={(value) => setFormData({ ...formData, type: value })}
        >
          <SelectTrigger className="bg-input border-border text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="income">Receita</SelectItem>
            <SelectItem value="expense">Despesa</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="category" className="text-foreground">Categoria</Label>
        <Select 
          value={formData.category} 
          onValueChange={(value) => setFormData({ ...formData, category: value })}
        >
          <SelectTrigger className="bg-input border-border text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {categories.map(cat => (
              <SelectItem key={cat} value={cat}>
                {cat}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex gap-2">
        <Button 
          type="submit"
          className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
        >
          Adicionar
        </Button>
        <Button 
          type="button"
          onClick={onCancel}
          variant="outline"
          className="flex-1 bg-secondary hover:bg-secondary/80 text-secondary-foreground"
        >
          Cancelar
        </Button>
      </div>
    </form>
  )
}

