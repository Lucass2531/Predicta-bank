// Dicionário de palavras-chave para categorização automática
const categoryKeywords = {
  'Alimentação': [
    'supermercado', 'mercado', 'açougue', 'padaria', 'restaurante', 'lanchonete',
    'pizzaria', 'bar', 'café', 'comida', 'almoço', 'janta', 'refeição', 'pão',
    'leite', 'carne', 'fruta', 'verdura', 'arroz', 'feijão', 'macarrão', 'delivery',
    'ifood', 'uber eats', 'rappi', 'loggi', 'zomato', 'didi food'
  ],
  'Transporte': [
    'uber', 'táxi', 'ônibus', 'metrô', 'trem', 'combustível', 'gasolina', 'diesel',
    'estacionamento', 'moto', 'bicicleta', 'passagem', 'bilhete', 'viagem',
    '99', 'bolt', 'carona', 'combustível', 'manutenção do carro', 'carro'
  ],
  'Moradia': [
    'aluguel', 'condomínio', 'água', 'luz', 'energia', 'gás', 'internet', 'telefone',
    'tv', 'streaming', 'netflix', 'spotify', 'prime', 'disney', 'hbo', 'aluguel'
  ],
  'Saúde': [
    'farmácia', 'medicamento', 'médico', 'dentista', 'hospital', 'clínica',
    'academia', 'musculação', 'pilates', 'yoga', 'psicólogo', 'psiquiatra',
    'oftalmologista', 'dermatologista', 'cirurgião', 'consulta'
  ],
  'Educação': [
    'escola', 'faculdade', 'universidade', 'curso', 'aula', 'livro', 'material escolar',
    'uniforme', 'mensalidade', 'tutor', 'professor', 'educação', 'aprendizado'
  ],
  'Compras': [
    'loja', 'shopping', 'amazon', 'mercado livre', 'shein', 'aliexpress',
    'roupas', 'sapatos', 'bolsa', 'acessório', 'eletrônico', 'smartphone',
    'computador', 'notebook', 'tablet', 'fone', 'câmera'
  ],
  'Lazer': [
    'cinema', 'teatro', 'show', 'música', 'jogo', 'videogame', 'parque',
    'praia', 'montanha', 'viagem', 'hotel', 'pousada', 'resort', 'diversão',
    'festa', 'boate', 'balada', 'karaokê'
  ],
  'Trabalho': [
    'salário', 'bônus', 'comissão', 'freelancer', 'consultoria', 'serviço',
    'projeto', 'cliente', 'empresa', 'renda', 'ganho', 'receita'
  ],
  'Investimento': [
    'ação', 'fundo', 'criptomoeda', 'bitcoin', 'ethereum', 'bolsa', 'tesouro',
    'cdb', 'poupança', 'investimento', 'aplicação', 'rendimento', 'dividendo'
  ],
  'Seguro': [
    'seguro', 'apólice', 'proteção', 'cobertura', 'vida', 'saúde', 'carro',
    'casa', 'responsabilidade', 'civil'
  ]
}

/**
 * Classifica automaticamente uma transação em uma categoria
 * @param description - Descrição da transação
 * @returns Nome da categoria detectada ou 'Outros'
 */
export function classifyTransaction(description: string): string {
  const lowerDescription = description.toLowerCase().trim()

  // Procura por palavras-chave em cada categoria
  for (const [category, keywords] of Object.entries(categoryKeywords)) {
    for (const keyword of keywords) {
      if (lowerDescription.includes(keyword)) {
        return category
      }
    }
  }

  // Se nenhuma categoria foi encontrada, retorna 'Outros'
  return 'Outros'
}

/**
 * Detecta automaticamente se é receita ou despesa baseado na descrição
 * @param description - Descrição da transação
 * @returns 'income' ou 'expense'
 */
export function detectTransactionType(description: string): 'income' | 'expense' {
  const incomeKeywords = [
    'salário', 'bônus', 'comissão', 'freelancer', 'consultoria', 'renda',
    'ganho', 'receita', 'venda', 'lucro', 'reembolso', 'devolução',
    'presente', 'herança', 'prêmio', 'indenização'
  ]

  const lowerDescription = description.toLowerCase()

  for (const keyword of incomeKeywords) {
    if (lowerDescription.includes(keyword)) {
      return 'income'
    }
  }

  return 'expense'
}

/**
 * Sugere uma categoria baseado no histórico de transações
 * @param description - Descrição da transação
 * @param transactions - Histórico de transações
 * @returns Categoria sugerida
 */
export function suggestCategoryFromHistory(
  description: string,
  transactions: any[]
): string {
  // Primeiro tenta classificar automaticamente
  const autoClassified = classifyTransaction(description)
  if (autoClassified !== 'Outros') {
    return autoClassified
  }

  // Se não conseguir, procura por transações similares no histórico
  const lowerDescription = description.toLowerCase()
  const similarTransactions = transactions.filter(t => {
    const similarity = t.description.toLowerCase().split(' ').some(word =>
      lowerDescription.includes(word) && word.length > 3
    )
    return similarity
  })

  if (similarTransactions.length > 0) {
    // Retorna a categoria mais comum entre transações similares
    const categories = similarTransactions.map(t => t.category || 'Outros')
    const mostCommon = categories.reduce((a, b) =>
      categories.filter(v => v === a).length > categories.filter(v => v === b).length ? a : b
    )
    return mostCommon
  }

  return 'Outros'
}

