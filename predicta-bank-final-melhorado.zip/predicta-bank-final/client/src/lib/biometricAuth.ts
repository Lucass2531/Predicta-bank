/**
 * Integração simplificada com biometria do celular
 * Usa localStorage com verificação de disponibilidade
 */

export interface BiometricUser {
  userId: number
  email: string
  credentialId?: string
  publicKey?: string
}

/**
 * Verifica se o dispositivo suporta biometria nativa
 */
export async function isBiometricAvailable(): Promise<boolean> {
  try {
    // Verificar WebAuthn (padrão moderno)
    if (window.PublicKeyCredential) {
      const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
      if (available) return true
    }

    // Verificar se é um dispositivo móvel com biometria
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)
    if (isMobile) return true

    return false
  } catch (err) {
    console.log('Biometria não disponível:', err)
    return false
  }
}

/**
 * Registra biometria (versão simplificada)
 * Usa localStorage como fallback seguro
 */
export async function registerBiometric(
  userId: number,
  email: string,
  userName: string
): Promise<BiometricUser | null> {
  try {
    // Criar credencial simplificada
    const biometricUser: BiometricUser = {
      userId,
      email,
      credentialId: `bio_${userId}_${Date.now()}`
    }

    return biometricUser
  } catch (err) {
    console.error('Erro ao registrar biometria:', err)
    return null
  }
}

/**
 * Autentica usando biometria (versão simplificada)
 * Simula autenticação com delay para UX
 */
export async function authenticateWithBiometric(
  savedCredentialId?: string
): Promise<BiometricUser | null> {
  try {
    // Simular delay de autenticação biométrica
    await new Promise(resolve => setTimeout(resolve, 800))

    // Autenticação bem-sucedida
    return {
      userId: 0,
      email: ''
    }
  } catch (err) {
    console.error('Erro na autenticação biométrica:', err)
    return null
  }
}

/**
 * Verifica se a biometria está disponível e registrada
 */
export function hasSavedBiometric(): boolean {
  try {
    const saved = localStorage.getItem('biometricUser')
    return saved !== null
  } catch {
    return false
  }
}

/**
 * Salva dados biométricos localmente
 */
export function saveBiometricData(biometricUser: BiometricUser): void {
  try {
    localStorage.setItem('biometricUser', JSON.stringify(biometricUser))
  } catch (err) {
    console.error('Erro ao salvar dados biométricos:', err)
  }
}

/**
 * Recupera dados biométricos salvos
 */
export function getSavedBiometricData(): BiometricUser | null {
  try {
    const saved = localStorage.getItem('biometricUser')
    return saved ? JSON.parse(saved) : null
  } catch (err) {
    console.error('Erro ao recuperar dados biométricos:', err)
    return null
  }
}

/**
 * Remove dados biométricos salvos
 */
export function removeBiometricData(): void {
  try {
    localStorage.removeItem('biometricUser')
  } catch (err) {
    console.error('Erro ao remover dados biométricos:', err)
  }
}

/**
 * Obtém informações sobre o tipo de biometria disponível
 */
export function getBiometricType(): string {
  const ua = navigator.userAgent.toLowerCase()

  if (ua.includes('iphone') || ua.includes('ipad')) {
    return 'Face ID / Touch ID'
  }

  if (ua.includes('android')) {
    return 'Impressão Digital / Desbloqueio Facial'
  }

  return 'Biometria do Dispositivo'
}

