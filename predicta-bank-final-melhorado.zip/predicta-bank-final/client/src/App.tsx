import { useState, useEffect } from 'react';
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Login from "./components/Login.tsx";
import Dashboard from "./components/Dashboard.tsx";
import NotFound from "./pages/NotFound";
import "./App.css";

interface User {
  id: number;
  name: string;
  email: string;
  password: string;
  balance: number;
  transactions: any[];
}

function Router({ isAuthenticated, currentUser, onLogin, onLogout }: { isAuthenticated: boolean; currentUser: User | null; onLogin: (user: User) => void; onLogout: () => void }) {
  return (
    <Switch>
      <Route path="/login">
        {isAuthenticated ? (
          <Dashboard user={currentUser} onLogout={onLogout} />
        ) : (
          <Login onLogin={onLogin} />
        )}
      </Route>
      <Route path="/dashboard">
        {isAuthenticated ? (
          <Dashboard user={currentUser} onLogout={onLogout} />
        ) : (
          <Login onLogin={onLogin} />
        )}
      </Route>
      <Route path="/">
        {isAuthenticated ? (
          <Dashboard user={currentUser} onLogout={onLogout} />
        ) : (
          <Login onLogin={onLogin} />
        )}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    // Check if user is already logged in
    const user = localStorage.getItem('currentUser');
    if (user) {
      setCurrentUser(JSON.parse(user));
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
    localStorage.setItem('currentUser', JSON.stringify(user));
  };

  const handleLogout = (): void => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('currentUser');
  };

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router 
            isAuthenticated={isAuthenticated}
            currentUser={currentUser}
            onLogin={handleLogin}
            onLogout={handleLogout}
          />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

